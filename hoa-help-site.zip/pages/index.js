import React from 'react';

export default function Home() {
  return (
    <div className=\"min-h-screen bg-white text-slate-900 antialiased\">
      <header className=\"sticky top-0 z-50 bg-white/80 backdrop-blur border-b border-slate-200\">
        <div className=\"mx-auto max-w-7xl px-4 py-3 flex items-center justify-between\">
          <h1 className=\"text-xl font-black tracking-tight\">HOA.help</h1>
          <a href=\"#contact\" className=\"inline-block rounded-2xl bg-slate-900 text-white px-4 py-2 text-sm hover:opacity-90\">Get Proposal</a>
        </div>
      </header>

      <main className=\"mx-auto max-w-7xl px-4 py-16\">
        <h2 className=\"text-4xl md:text-6xl font-black tracking-tight leading-[1.05]\">Efficient HOA management</h2>
        <p className=\"mt-4 text-lg text-slate-600 max-w-prose\">We combine 24/7 support with disciplined financial controls so your community runs smoothly and builds healthy reserves.</p>
      </main>

      <footer className=\"border-t mt-16\">
        <div className=\"mx-auto max-w-7xl px-4 py-10 text-sm\">
          <p>© {new Date().getFullYear()} HOA.help — All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
